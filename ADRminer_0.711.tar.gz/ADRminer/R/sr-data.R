#' @encoding UTF-8
#' @title spontaneous reporting dataset szqcription
#' @description Spontaneous reporting dataset in a \code{data.frame} format. This dataset has to be transformed 
#' into an pvInd object by means of \code{pvInd} 
#' @name sr-data
#' @docType data
#' @keywords data
#' @aliases sr1
#' @aliases sr2
#' @aliases covSr1
#' 
NA
